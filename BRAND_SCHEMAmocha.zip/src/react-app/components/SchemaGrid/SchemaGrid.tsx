import { motion } from 'framer-motion';
import SchemaCard from './SchemaCard';

const schemaItems = [
  {
    id: 'vision-file',
    title: 'Vision File',
    description: 'Parseable brand purpose and positioning',
  },
  {
    id: 'voice-protocol',
    title: 'Voice Protocol',
    description: 'Codified tone and personality',
  },
  {
    id: 'semantic-stack',
    title: 'Semantic Stack',
    description: 'Content themes and interlinking',
  },
  {
    id: 'metadata-matrix',
    title: 'Metadata Matrix',
    description: 'Schema rules and taxonomy',
  },
  {
    id: 'asset-registry',
    title: 'Asset Registry',
    description: 'Modular content components',
  },
  {
    id: 'signal-ruleset',
    title: 'Signal Ruleset',
    description: 'Brand expression logic',
  },
  {
    id: 'lexicon-layer',
    title: 'Lexicon Layer',
    description: 'Shared terms and phrases',
  },
  {
    id: 'audit-trail',
    title: 'Audit Trail',
    description: 'Brand change log',
  },
];

export default function SchemaGrid() {
  return (
    <div className="w-full h-screen bg-black overflow-y-auto">
      <div className="container mx-auto px-6 py-12 ml-[15vw]">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <h1 className="font-display text-5xl font-bold mb-4 text-white tracking-wide">
            SCHEMA GRID
          </h1>
          <p className="font-body text-xl text-gray-400 max-w-2xl">
            Structured brand components for machine-readable identity systems.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.1
              }
            }
          }}
        >
          {schemaItems.map((item) => (
            <motion.div
              key={item.id}
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 }
              }}
            >
              <SchemaCard {...item} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
