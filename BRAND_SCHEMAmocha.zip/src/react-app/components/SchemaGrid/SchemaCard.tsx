import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { X } from 'lucide-react';

interface SchemaCardProps {
  id: string;
  title: string;
  description: string;
}

const leetText = (text: string) => {
  return text
    .replace(/e/gi, '3')
    .replace(/a/gi, '4')
    .replace(/o/gi, '0')
    .replace(/i/gi, '1')
    .replace(/s/gi, '5');
};

export default function SchemaCard({ id, title, description }: SchemaCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [isGlitching, setIsGlitching] = useState(false);

  const handleClick = () => {
    setShowModal(true);
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
    setIsGlitching(true);
    setTimeout(() => setIsGlitching(false), 200);
  };

  return (
    <>
      <motion.div
        className="relative h-48 bg-transparent border border-gray-700 cursor-pointer group"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={() => setIsHovered(false)}
        onClick={handleClick}
        whileHover={{ 
          scale: 1.02,
          transition: { duration: 0.2, ease: [0.65, 0, 0.35, 1] }
        }}
        whileTap={{ scale: 0.98 }}
      >
        {/* Glitch flicker effect */}
        <AnimatePresence>
          {isGlitching && (
            <motion.div
              className="absolute inset-0 bg-red-500 mix-blend-multiply"
              initial={{ opacity: 0 }}
              animate={{ 
                opacity: [0, 0.3, 0, 0.5, 0],
                x: [0, 2, -2, 1, 0]
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            />
          )}
        </AnimatePresence>

        <div className="p-6 h-full flex flex-col justify-between">
          <div>
            <h3 className="font-display text-lg font-bold text-white mb-2 tracking-wide">
              {isGlitching ? leetText(title) : title}
            </h3>
            <p className="font-body text-sm text-gray-400 leading-relaxed">
              {isGlitching ? leetText(description) : description}
            </p>
          </div>
          
          <div className="text-xs font-display text-gray-600 tracking-wider">
            {id.toUpperCase()}
          </div>
        </div>

        {/* Hover glow */}
        {isHovered && (
          <motion.div
            className="absolute inset-0 border border-red-500 pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
        )}
      </motion.div>

      {/* Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowModal(false)}
          >
            <motion.div
              className="bg-black border border-gray-700 p-8 max-w-md w-full mx-4"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ ease: [0.65, 0, 0.35, 1] }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-start mb-4">
                <h2 className="font-display text-xl font-bold text-white tracking-wide">
                  {title}
                </h2>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <p className="font-body text-gray-400 mb-6 leading-relaxed">
                {description}
              </p>
              
              <div className="text-xs font-display text-gray-600 tracking-wider">
                PLACEHOLDER MODAL - {id.toUpperCase()}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
