import { motion, AnimatePresence } from 'framer-motion';
import { ReactNode } from 'react';

interface NewLayerTransitionProps {
  children: ReactNode;
  layerId: number;
  currentLayer: number;
}

export default function NewLayerTransition({ children, layerId, currentLayer }: NewLayerTransitionProps) {
  const isActive = currentLayer === layerId;
  
  // Calculate scale and opacity based on depth
  const getTransformValues = (id: number, current: number) => {
    if (id === current) return { scale: 1, opacity: 1 };
    const distance = Math.abs(id - current);
    return {
      scale: 1 - (distance * 0.05), // 1 → 0.95 → 0.9
      opacity: 1 - (distance * 0.2)  // 1 → 0.8 → 0.6
    };
  };
  
  const { scale, opacity } = getTransformValues(layerId, currentLayer);
  
  return (
    <div 
      className="absolute inset-0 w-full h-full"
      style={{ 
        perspective: '1500px',
        transformStyle: 'preserve-3d'
      }}
    >
      <AnimatePresence mode="sync">
        <motion.div
          key={layerId}
          initial={{ 
            scale: 0.9,
            opacity: 0,
            rotateX: layerId > currentLayer ? -10 : 10
          }}
          animate={{ 
            scale,
            opacity,
            rotateX: 0,
            zIndex: isActive ? 10 : layerId < currentLayer ? 5 : 1
          }}
          exit={{ 
            scale: 0.9,
            opacity: 0,
            rotateX: layerId > currentLayer ? 10 : -10
          }}
          transition={{ 
            duration: 0.6, 
            ease: [0.22, 1, 0.36, 1],
            scale: { duration: 0.4 },
            opacity: { duration: 0.3 }
          }}
          className={cn(
            "absolute inset-0 w-full h-full origin-center",
            !isActive ? "pointer-events-none" : ""
          )}
          style={{ 
            transformOrigin: 'center center',
            transformStyle: 'preserve-3d'
          }}
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function cn(...classes: (string | undefined)[]): string {
  return classes.filter(Boolean).join(' ');
}
