import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/react-app/components/ui/card';
import { Button } from '@/react-app/components/ui/button';
import { 
  Network, 
  Database, 
  Code2, 
  Layers3, 
  GitGraph,
  Cpu,
  HardDrive,
  Wifi
} from 'lucide-react';

const schemaComponents = [
  {
    title: 'Data Architecture',
    description: 'Core information structures and relationships',
    icon: Database,
    connections: 8,
    status: 'OPTIMIZED'
  },
  {
    title: 'Logic Framework',
    description: 'Business rules and computational logic',
    icon: Code2,
    connections: 12,
    status: 'ACTIVE'
  },
  {
    title: 'Interface Layer',
    description: 'User interaction and presentation logic',
    icon: Layers3,
    connections: 6,
    status: 'STABLE'
  },
  {
    title: 'Process Flow',
    description: 'Workflow orchestration and state management',
    icon: GitGraph,
    connections: 10,
    status: 'EVOLVING'
  }
];

export default function SchemaLayer() {
  return (
    <div className="w-full h-screen bg-gradient-to-br from-brand-dark via-semantic-bg to-brand-light overflow-y-auto">
      <div className="container mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <h1 className="font-display text-5xl font-bold mb-4 text-brand-tertiary">
            SCHEMA
          </h1>
          <p className="font-body text-xl text-semantic-muted max-w-2xl mb-8">
            The fundamental architecture underlying all system operations. 
            Here lies the core logic that defines relationships, constraints, and evolutionary patterns.
          </p>
        </motion.div>

        {/* System overview */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="mb-12 bg-semantic-surface/30 backdrop-blur-md border border-semantic-border rounded-lg p-8"
        >
          <div className="text-center mb-8">
            <div className="relative inline-block">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="w-32 h-32 border-2 border-brand-tertiary/30 rounded-full flex items-center justify-center"
              >
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                  className="w-20 h-20 border-2 border-brand-accent/50 rounded-full flex items-center justify-center"
                >
                  <Network className="w-8 h-8 text-brand-tertiary" />
                </motion.div>
              </motion.div>
              <div className="absolute inset-0 bg-gradient-to-r from-brand-tertiary/20 to-brand-accent/20 rounded-full blur-xl -z-10" />
            </div>
            <h2 className="font-display text-3xl font-bold mt-6 mb-2">CORE SCHEMA</h2>
            <p className="text-semantic-muted">Unified system architecture</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <Cpu className="w-8 h-8 text-brand-tertiary mx-auto mb-3" />
              <div className="font-display text-lg font-semibold text-semantic-text">PROCESSING</div>
              <div className="text-sm text-semantic-muted">Real-time computation</div>
            </div>
            <div className="text-center">
              <HardDrive className="w-8 h-8 text-brand-accent mx-auto mb-3" />
              <div className="font-display text-lg font-semibold text-semantic-text">STORAGE</div>
              <div className="text-sm text-semantic-muted">Persistent state</div>
            </div>
            <div className="text-center">
              <Wifi className="w-8 h-8 text-brand-secondary mx-auto mb-3" />
              <div className="font-display text-lg font-semibold text-semantic-text">NETWORK</div>
              <div className="text-sm text-semantic-muted">Distributed communication</div>
            </div>
          </div>
        </motion.div>

        {/* Schema components */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.1
              }
            }
          }}
        >
          {schemaComponents.map((component) => (
            <motion.div
              key={component.title}
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 }
              }}
              className="group"
            >
              <Card className="h-full bg-semantic-surface/50 backdrop-blur-md border-semantic-border hover:border-brand-tertiary/50 transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 rounded-lg bg-brand-tertiary/10 border border-brand-tertiary/20">
                      <component.icon className="w-6 h-6 text-brand-tertiary" />
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-display text-semantic-muted tracking-wider mb-1">
                        {component.status}
                      </div>
                      <div className="text-sm text-brand-tertiary font-semibold">
                        {component.connections} connections
                      </div>
                    </div>
                  </div>
                  <CardTitle className="text-xl">{component.title}</CardTitle>
                  <CardDescription className="text-base">
                    {component.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="outline" 
                    className="w-full font-display group-hover:bg-brand-tertiary/10 group-hover:text-brand-tertiary"
                  >
                    EXPLORE STRUCTURE
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Schema integrity */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="bg-semantic-surface/30 backdrop-blur-md border border-semantic-border rounded-lg p-8"
        >
          <h2 className="font-display text-2xl font-bold mb-6 text-semantic-text">
            SYSTEM INTEGRITY
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-brand-accent mb-2">
                99.9%
              </div>
              <div className="text-sm text-semantic-muted">CONSISTENCY</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-brand-tertiary mb-2">
                REAL-TIME
              </div>
              <div className="text-sm text-semantic-muted">SYNCHRONIZATION</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-brand-secondary mb-2">
                ADAPTIVE
              </div>
              <div className="text-sm text-semantic-muted">EVOLUTION</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-semantic-text mb-2">
                SECURE
              </div>
              <div className="text-sm text-semantic-muted">VALIDATION</div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
