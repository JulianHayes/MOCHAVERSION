import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/react-app/components/ui/card';
import { Button } from '@/react-app/components/ui/button';
import { 
  Brain, 
  Target, 
  Workflow, 
  Shield, 
  Lightbulb, 
  GitBranch,
  Activity,
  Eye
} from 'lucide-react';

const agents = [
  {
    icon: Brain,
    title: 'Architect',
    description: 'Strategic system design and planning',
    status: 'ACTIVE',
    tasks: 12,
    efficiency: 94
  },
  {
    icon: Target,
    title: 'Optimizer',
    description: 'Performance enhancement and resource management',
    status: 'PROCESSING',
    tasks: 8,
    efficiency: 87
  },
  {
    icon: Workflow,
    title: 'Orchestrator',
    description: 'Workflow automation and process coordination',
    status: 'STANDBY',
    tasks: 4,
    efficiency: 91
  },
  {
    icon: Shield,
    title: 'Guardian',
    description: 'Security monitoring and threat assessment',
    status: 'ACTIVE',
    tasks: 6,
    efficiency: 99
  },
  {
    icon: Lightbulb,
    title: 'Innovator',
    description: 'Pattern recognition and solution generation',
    status: 'LEARNING',
    tasks: 15,
    efficiency: 89
  },
  {
    icon: GitBranch,
    title: 'Versioner',
    description: 'Change management and evolution tracking',
    status: 'ACTIVE',
    tasks: 3,
    efficiency: 96
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'ACTIVE': return 'brand-accent';
    case 'PROCESSING': return 'brand-tertiary';
    case 'LEARNING': return 'brand-secondary';
    default: return 'semantic-muted';
  }
};

export default function AgentsLayer() {
  return (
    <div className="w-full h-screen bg-gradient-to-br from-semantic-bg via-brand-medium to-brand-dark overflow-y-auto">
      <div className="container mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <h1 className="font-display text-5xl font-bold mb-4 text-brand-secondary">
            AGENTS
          </h1>
          <p className="font-body text-xl text-semantic-muted max-w-2xl mb-8">
            Autonomous intelligence systems operating at strategic depth. 
            Each agent specializes in specific domains while maintaining awareness of the larger context.
          </p>
          
          {/* System metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-semantic-surface/50 backdrop-blur-md border border-semantic-border rounded-lg p-4">
              <div className="text-2xl font-display font-bold text-brand-accent">06</div>
              <div className="text-sm text-semantic-muted">ACTIVE AGENTS</div>
            </div>
            <div className="bg-semantic-surface/50 backdrop-blur-md border border-semantic-border rounded-lg p-4">
              <div className="text-2xl font-display font-bold text-brand-tertiary">48</div>
              <div className="text-sm text-semantic-muted">TOTAL TASKS</div>
            </div>
            <div className="bg-semantic-surface/50 backdrop-blur-md border border-semantic-border rounded-lg p-4">
              <div className="text-2xl font-display font-bold text-brand-secondary">92%</div>
              <div className="text-sm text-semantic-muted">AVG EFFICIENCY</div>
            </div>
            <div className="bg-semantic-surface/50 backdrop-blur-md border border-semantic-border rounded-lg p-4">
              <div className="text-2xl font-display font-bold text-semantic-text">24/7</div>
              <div className="text-sm text-semantic-muted">UPTIME</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.15
              }
            }
          }}
        >
          {agents.map((agent) => (
            <motion.div
              key={agent.title}
              variants={{
                hidden: { opacity: 0, x: -20, scale: 0.95 },
                visible: { opacity: 1, x: 0, scale: 1 }
              }}
              whileHover={{ 
                scale: 1.02,
                transition: { duration: 0.2 }
              }}
              className="group"
            >
              <Card className="bg-semantic-surface/50 backdrop-blur-md border-semantic-border hover:border-brand-secondary/50 transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-3 rounded-lg bg-brand-secondary/10 border border-brand-secondary/20">
                        <agent.icon className="w-6 h-6 text-brand-secondary" />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{agent.title}</CardTitle>
                        <div className="flex items-center space-x-2 mt-1">
                          <div className={`w-2 h-2 rounded-full bg-${getStatusColor(agent.status)} animate-pulse`} />
                          <span className={`text-xs font-display text-${getStatusColor(agent.status)} tracking-wider`}>
                            {agent.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <CardDescription className="text-base mb-4">
                    {agent.description}
                  </CardDescription>
                  
                  {/* Agent metrics */}
                  <div className="flex justify-between items-center text-sm">
                    <div className="flex items-center space-x-1">
                      <Activity className="w-4 h-4 text-semantic-muted" />
                      <span className="text-semantic-muted">{agent.tasks} tasks</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Target className="w-4 h-4 text-brand-accent" />
                      <span className="text-brand-accent font-medium">{agent.efficiency}%</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex-1 font-display"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      MONITOR
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="flex-1 font-display group-hover:bg-brand-secondary/10 group-hover:text-brand-secondary"
                    >
                      CONFIGURE
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Agent network visualization */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-16 bg-semantic-surface/30 backdrop-blur-md border border-semantic-border rounded-lg p-8"
        >
          <h2 className="font-display text-2xl font-bold mb-6 text-semantic-text">
            NETWORK STATUS
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-brand-accent mb-2">
                HIGH
              </div>
              <div className="text-sm text-semantic-muted">COLLABORATION LEVEL</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-brand-tertiary mb-2">
                OPTIMAL
              </div>
              <div className="text-sm text-semantic-muted">RESOURCE ALLOCATION</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-brand-secondary mb-2">
                STABLE
              </div>
              <div className="text-sm text-semantic-muted">SYSTEM INTEGRITY</div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
