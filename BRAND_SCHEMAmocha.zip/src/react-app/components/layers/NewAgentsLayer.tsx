import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/react-app/components/ui/card';
import { Button } from '@/react-app/components/ui/button';
import { 
  Brain, 
  Shield, 
  MessageSquare, 
  BarChart3,
  ArrowRight
} from 'lucide-react';

const agents = [
  {
    id: 'AGENT_01',
    icon: Brain,
    title: 'BRAND:STRATEGY agent',
    description: 'Builds clarity. Signals authority.',
    buttonText: 'Engage Agent'
  },
  {
    id: 'AGENT_02',
    icon: Shield,
    title: 'BRAND:MANAGEMENT agent',
    description: 'Applies structure. Maintains consistency.',
    buttonText: 'Engage Agent'
  },
  {
    id: 'AGENT_03',
    icon: MessageSquare,
    title: 'BRAND:MARKETING agent',
    description: 'Writes for bots. Resonates with humans.',
    buttonText: 'Engage Agent'
  },
  {
    id: 'AGENT_04',
    icon: BarChart3,
    title: 'BRAND:INTELLIGENCE agent',
    description: 'Tracks mentions. Measures impact.',
    buttonText: 'Engage Agent'
  }
];

export default function NewAgentsLayer() {
  return (
    <div className="w-full h-screen bg-gradient-to-br from-semantic-bg via-brand-medium to-brand-dark overflow-y-auto">
      <div className="container mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <h1 className="font-display text-5xl font-bold mb-4 text-semantic-text tracking-wide">
            Structured strategy for machine-scale visibility.
          </h1>
          <p className="font-body text-xl text-brand-accent max-w-2xl font-bold tracking-wide">
            Once you see the gaps, use agents to close them.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.15
              }
            }
          }}
        >
          {agents.map((agent) => (
            <motion.div
              key={agent.id}
              variants={{
                hidden: { opacity: 0, y: 30, scale: 0.95 },
                visible: { opacity: 1, y: 0, scale: 1 }
              }}
              whileHover={{ 
                scale: 1.02,
                transition: { duration: 0.2 }
              }}
              className="group"
            >
              <Card className="h-full bg-semantic-surface/50 backdrop-blur-md border-semantic-border hover:border-brand-accent/50 transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 rounded-lg bg-brand-accent/10 border border-brand-accent/20">
                      <agent.icon className="w-6 h-6 text-brand-accent" />
                    </div>
                    <span className="text-xs font-display text-semantic-muted tracking-wider">
                      {agent.id}
                    </span>
                  </div>
                  <CardTitle className="text-xl font-display tracking-wide">{agent.title}</CardTitle>
                  <CardDescription className="text-base font-body leading-relaxed">
                    {agent.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="default"
                    className="w-full justify-between font-display tracking-wide bg-brand-accent text-semantic-bg hover:bg-brand-accent/90"
                  >
                    <span>→ [ {agent.buttonText} ]</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Strategic depth indicator */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-16 bg-semantic-surface/30 backdrop-blur-md border border-semantic-border rounded-lg p-8"
        >
          <h2 className="font-display text-2xl font-bold mb-4 text-semantic-text tracking-wide">
            STRATEGIC DEPTH
          </h2>
          <p className="font-body text-semantic-muted text-lg leading-relaxed mb-6">
            These agents work at the strategic layer, building comprehensive brand systems 
            that maintain consistency across all touchpoints and optimize for machine visibility.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-display font-bold text-brand-accent mb-2">
                CLARITY
              </div>
              <div className="text-sm font-body text-semantic-muted">Strategic Foundation</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-display font-bold text-brand-accent mb-2">
                STRUCTURE
              </div>
              <div className="text-sm font-body text-semantic-muted">Consistent Application</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-display font-bold text-brand-accent mb-2">
                RESONANCE
              </div>
              <div className="text-sm font-body text-semantic-muted">Human + Machine</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-display font-bold text-brand-accent mb-2">
                INTELLIGENCE
              </div>
              <div className="text-sm font-body text-semantic-muted">Impact Measurement</div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
