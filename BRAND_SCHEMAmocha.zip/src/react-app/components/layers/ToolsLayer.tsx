import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/react-app/components/ui/card';
import { Button } from '@/react-app/components/ui/button';
import { 
  Code, 
  Database, 
  Palette, 
  FileText, 
  Layers, 
  Zap,
  ArrowRight,
  Settings
} from 'lucide-react';

const tools = [
  {
    icon: Code,
    title: 'Code Generator',
    description: 'Transform concepts into executable code',
    category: 'Development',
    color: 'brand-accent'
  },
  {
    icon: Database,
    title: 'Schema Builder',
    description: 'Design and optimize data structures',
    category: 'Architecture',
    color: 'brand-tertiary'
  },
  {
    icon: Palette,
    title: 'Design System',
    description: 'Create cohesive visual languages',
    category: 'Design',
    color: 'brand-secondary'
  },
  {
    icon: FileText,
    title: 'Documentation',
    description: 'Generate comprehensive system docs',
    category: 'Knowledge',
    color: 'brand-accent'
  },
  {
    icon: Layers,
    title: 'Component Library',
    description: 'Reusable interface elements',
    category: 'UI/UX',
    color: 'brand-tertiary'
  },
  {
    icon: Settings,
    title: 'Configuration',
    description: 'System optimization and tuning',
    category: 'Operations',
    color: 'brand-secondary'
  }
];

export default function ToolsLayer() {
  return (
    <div className="w-full h-screen bg-gradient-to-br from-brand-dark via-semantic-bg to-brand-medium overflow-y-auto">
      <div className="container mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <h1 className="font-display text-5xl font-bold mb-4 text-brand-accent">
            TOOLS
          </h1>
          <p className="font-body text-xl text-semantic-muted max-w-2xl">
            Action-oriented instruments for immediate productivity. 
            Each tool operates independently while contributing to the larger semantic framework.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.1
              }
            }
          }}
        >
          {tools.map((tool) => (
            <motion.div
              key={tool.title}
              variants={{
                hidden: { opacity: 0, y: 20, scale: 0.95 },
                visible: { opacity: 1, y: 0, scale: 1 }
              }}
              whileHover={{ 
                scale: 1.02,
                y: -5,
                transition: { duration: 0.2 }
              }}
              className="group"
            >
              <Card className="h-full bg-semantic-surface/50 backdrop-blur-md border-semantic-border hover:border-brand-accent/50 transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 rounded-lg bg-${tool.color}/10 border border-${tool.color}/20`}>
                      <tool.icon className={`w-6 h-6 text-${tool.color}`} />
                    </div>
                    <span className="text-xs font-display text-semantic-muted tracking-wider">
                      {tool.category.toUpperCase()}
                    </span>
                  </div>
                  <CardTitle className="text-xl">{tool.title}</CardTitle>
                  <CardDescription className="text-base">
                    {tool.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-between group-hover:bg-brand-accent/10 group-hover:text-brand-accent transition-colors"
                  >
                    <span className="font-display">LAUNCH</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Quick actions */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-16 bg-semantic-surface/30 backdrop-blur-md border border-semantic-border rounded-lg p-8"
        >
          <h2 className="font-display text-2xl font-bold mb-6 text-semantic-text">
            QUICK ACTIONS
          </h2>
          <div className="flex flex-wrap gap-4">
            <Button variant="outline" className="font-display">
              <Zap className="w-4 h-4 mr-2" />
              NEW PROJECT
            </Button>
            <Button variant="outline" className="font-display">
              <FileText className="w-4 h-4 mr-2" />
              IMPORT SCHEMA
            </Button>
            <Button variant="outline" className="font-display">
              <Database className="w-4 h-4 mr-2" />
              SYNC DATA
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
