import { motion } from 'framer-motion';

interface HeroLayerProps {
  onNavigate: (layer: number) => void;
}

export default function HeroLayer({ onNavigate }: HeroLayerProps) {
  return (
    <div className="relative w-full h-screen bg-black overflow-hidden ml-[15vw]">
      {/* Main content */}
      <div className="flex flex-col items-center justify-center h-full text-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2, ease: [0.65, 0, 0.35, 1] }}
          className="max-w-4xl"
        >
          <motion.h1 
            className="font-display text-6xl md:text-7xl font-bold mb-6 text-white tracking-wide"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, delay: 0.4, ease: [0.65, 0, 0.35, 1] }}
          >
            Built to Be Picked.
          </motion.h1>
          
          <motion.h2 
            className="font-display text-2xl md:text-3xl font-bold text-red-500 mb-8 tracking-wide"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.6, ease: [0.65, 0, 0.35, 1] }}
          >
            Your brand, structured for the age of AI.
          </motion.h2>

          <motion.p 
            className="font-body text-lg md:text-xl text-gray-400 mb-12 leading-relaxed max-w-3xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.8, ease: [0.65, 0, 0.35, 1] }}
          >
            Search is now a chat. Screens are vanishing. AI agents choose what gets seen, quoted, and bought. 
            If your brand isn't machine-readable, it isn't visible.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1, ease: [0.65, 0, 0.35, 1] }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
          >
            <motion.button
              className="px-8 py-4 text-lg font-display font-semibold bg-red-500 text-black tracking-wide hover:bg-red-600 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              [ Get the Survival Manual ]
            </motion.button>
            
            <motion.button
              onClick={() => onNavigate(1)}
              className="px-8 py-4 text-lg font-display font-semibold bg-transparent border border-gray-700 text-white tracking-wide hover:border-red-500 hover:text-red-500 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              [ Run a Visibility Audit ]
            </motion.button>
          </motion.div>
        </motion.div>

        {/* System info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2, ease: [0.65, 0, 0.35, 1] }}
          className="absolute bottom-8 font-display text-xs text-gray-500 tracking-wider"
        >
          <div className="flex items-center space-x-6">
            <span>BRAND:SCHEMA OS</span>
            <span>•</span>
            <span>Z-AXIS NAVIGATION</span>
            <span>•</span>
            <span>MACHINE-READABLE</span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
