import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/react-app/components/ui/card';
import { Button } from '@/react-app/components/ui/button';
import { 
  FileEdit, 
  Users, 
  Settings,
  ArrowRight,
  Eye
} from 'lucide-react';

const tools = [
  {
    id: 'TOOL_01',
    icon: Eye,
    title: 'AI VISIBILITY AUDITOR',
    description: 'Track your mentions. See who\'s quoting you. Know where you stand.',
    buttonText: 'Run Audit',
    available: true
  },
  {
    id: 'TOOL_02',
    icon: FileEdit,
    title: 'CONTENT OPTIMISER',
    description: 'Make your message machine-readable. Structure it for search, feeds, and AI.',
    buttonText: 'Optimise Content',
    available: true
  },
  {
    id: 'TOOL_03',
    icon: Users,
    title: 'COMPETITOR TRACKER',
    description: 'Monitor rivals. Compare citations. Find your semantic white space.',
    buttonText: 'Track Competitors',
    available: true
  },
  {
    id: 'TOOL_04',
    icon: Settings,
    title: 'SCHEMA GENERATOR',
    description: 'Turn brand strategy into deployable schema—fast.',
    buttonText: 'Preview Tool',
    available: false,
    comingSoon: true
  }
];

export default function NewToolsLayer() {
  return (
    <div className="w-full h-screen bg-gradient-to-br from-brand-dark via-semantic-bg to-brand-medium overflow-y-auto">
      <div className="container mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <h1 className="font-display text-5xl font-bold mb-4 text-semantic-text tracking-wide">
            Machine-first visibility starts here.
          </h1>
          <p className="font-body text-xl text-brand-accent max-w-2xl font-bold tracking-wide">
            Start with tools. Get feedback. Build forward.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.15
              }
            }
          }}
        >
          {tools.map((tool) => (
            <motion.div
              key={tool.id}
              variants={{
                hidden: { opacity: 0, y: 30, scale: 0.95 },
                visible: { opacity: 1, y: 0, scale: 1 }
              }}
              whileHover={{ 
                scale: 1.02,
                transition: { duration: 0.2 }
              }}
              className="group"
            >
              <Card className="h-full bg-semantic-surface/50 backdrop-blur-md border-semantic-border hover:border-brand-accent/50 transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 rounded-lg bg-brand-accent/10 border border-brand-accent/20">
                      <tool.icon className="w-6 h-6 text-brand-accent" />
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-display text-semantic-muted tracking-wider">
                        {tool.id}
                      </span>
                      {tool.comingSoon && (
                        <div className="text-xs font-display text-brand-accent tracking-wider mt-1">
                          COMING SOON
                        </div>
                      )}
                    </div>
                  </div>
                  <CardTitle className="text-xl font-display tracking-wide">{tool.title}</CardTitle>
                  <CardDescription className="text-base font-body leading-relaxed">
                    {tool.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant={tool.available ? "default" : "outline"}
                    disabled={!tool.available}
                    className="w-full justify-between font-display tracking-wide"
                  >
                    <span>→ [ {tool.buttonText} ]</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Additional info */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-16 bg-semantic-surface/30 backdrop-blur-md border border-semantic-border rounded-lg p-8"
        >
          <h2 className="font-display text-2xl font-bold mb-4 text-semantic-text tracking-wide">
            START HERE
          </h2>
          <p className="font-body text-semantic-muted text-lg leading-relaxed">
            Each tool gives you immediate insights into your brand's machine visibility. 
            Start with the auditor to understand your current position, then optimise your content for AI systems.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
