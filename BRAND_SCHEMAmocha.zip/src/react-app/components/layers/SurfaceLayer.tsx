import { motion } from 'framer-motion';
import { Button } from '@/react-app/components/ui/button';
import { ChevronDown, Zap } from 'lucide-react';

interface SurfaceLayerProps {
  onEnter: () => void;
}

export default function SurfaceLayer({ onEnter }: SurfaceLayerProps) {
  return (
    <div className="relative w-full h-screen bg-gradient-to-br from-semantic-bg via-brand-dark to-semantic-bg overflow-hidden">
      {/* Grid overlay */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,255,136,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,255,136,0.1) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px'
        }}
      />
      
      {/* Floating particles */}
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-brand-accent rounded-full"
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: 0
          }}
          animate={{ 
            y: [null, -20, 20, -10],
            opacity: [0, 1, 0.5, 1, 0]
          }}
          transition={{
            duration: 6 + Math.random() * 4,
            repeat: Infinity,
            delay: Math.random() * 2
          }}
        />
      ))}

      {/* Main content */}
      <div className="flex flex-col items-center justify-center h-full text-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="max-w-4xl"
        >
          <motion.h1 
            className="font-display text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-brand-accent via-semantic-text to-brand-tertiary bg-clip-text text-transparent"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, delay: 0.4 }}
          >
            BRAND:SCHEMA
          </motion.h1>
          
          <motion.p 
            className="font-body text-xl md:text-2xl text-semantic-muted mb-8 leading-relaxed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.6 }}
          >
            Minimalist retrofuturist semantic OS
            <br />
            <span className="text-brand-accent">Navigate through structured layers of intelligence</span>
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Button 
              onClick={onEnter}
              size="lg"
              className="group relative px-8 py-4 text-lg font-semibold animate-glow"
            >
              <Zap className="w-5 h-5 mr-2 group-hover:animate-pulse" />
              ENTER SYSTEM
            </Button>
            
            <div className="flex items-center text-semantic-muted">
              <span className="text-sm font-display">DEPTH AWAITS</span>
              <ChevronDown className="w-4 h-4 ml-2 animate-bounce" />
            </div>
          </motion.div>
        </motion.div>

        {/* System info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="absolute bottom-8 font-display text-xs text-semantic-muted tracking-wider"
        >
          <div className="flex items-center space-x-6">
            <span>SEMANTIC OS v2.1</span>
            <span>•</span>
            <span>Z-AXIS NAVIGATION</span>
            <span>•</span>
            <span>TOOLS-FIRST APPROACH</span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
