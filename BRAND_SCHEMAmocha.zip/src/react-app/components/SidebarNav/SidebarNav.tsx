import { motion } from 'framer-motion';
import { Grid3X3, Wrench, Bot } from 'lucide-react';

interface SidebarNavProps {
  currentLayer: number;
  onLayerChange: (layer: number) => void;
}

const layers = [
  { id: 0, label: 'Hero', icon: Grid3X3, desc: 'Brand Foundation' },
  { id: 1, label: 'Schema', icon: Wrench, desc: 'System Architecture' },
  { id: 2, label: 'Agents', icon: Bot, desc: 'Strategic Intelligence' },
];

export default function SidebarNav({ currentLayer, onLayerChange }: SidebarNavProps) {
  return (
    <motion.nav
      initial={{ opacity: 0, x: -40 }}
      animate={{ opacity: 1, x: 0 }}
      className="fixed left-0 top-0 h-screen w-[15vw] min-w-[200px] z-50 bg-black border-r border-gray-800"
      style={{ minHeight: '600px' }}
    >
      <div className="flex flex-col h-full p-6">
        {/* Logo - positioned at 25vh */}
        <motion.button
          onClick={() => onLayerChange(0)}
          className="text-left group mb-12"
          style={{ marginTop: '25vh' }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <motion.div 
            className="font-display text-xl font-bold text-red-500 tracking-wider"
            animate={{ opacity: [1, 0.7, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            BRAND:SCHEMA
          </motion.div>
          <div className="font-body text-xs text-gray-500 mt-1">
            Semantic OS
          </div>
        </motion.button>

        {/* Navigation items */}
        <div className="flex-1 space-y-4">
          {layers.map((layer) => {
            const Icon = layer.icon;
            const isActive = currentLayer === layer.id;
            
            return (
              <motion.button
                key={layer.id}
                onClick={() => onLayerChange(layer.id)}
                className={`w-full text-left px-4 py-3 transition-all duration-300 group flex items-center space-x-3 ${
                  isActive
                    ? "text-red-500 border-l-2 border-red-500"
                    : "text-gray-400 hover:text-white"
                }`}
                whileHover={{ x: isActive ? 0 : 8 }}
                whileTap={{ scale: 0.98 }}
              >
                {/* Icon with active indicator */}
                <div className="relative">
                  <Icon className={`w-5 h-5 transition-colors ${
                    isActive ? "text-red-500" : "text-gray-400 group-hover:text-white"
                  }`} />
                  {isActive && (
                    <motion.div
                      className="absolute -left-2 top-1/2 w-2 h-2 bg-red-500 rounded-full"
                      animate={{ scale: [1, 1.2, 1], opacity: [1, 0.7, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                      style={{ transform: 'translateY(-50%)' }}
                    />
                  )}
                </div>
                
                {/* Label and description */}
                <div>
                  <div className={`font-display font-semibold tracking-wide text-sm ${
                    isActive ? "text-red-500" : "group-hover:text-white"
                  }`}>
                    {layer.label}
                  </div>
                  <div className="font-body text-xs opacity-70">
                    {layer.desc}
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>
        
        {/* Layer indicator */}
        <div className="mt-6 pt-4 border-t border-gray-800">
          <div className="font-display text-xs text-gray-500 tracking-wider">
            Z = {currentLayer} / DEPTH = {currentLayer === 0 ? 'SURFACE' : currentLayer === 1 ? 'SCHEMA' : 'AGENTS'}
          </div>
        </div>
      </div>
    </motion.nav>
  );
}
