import { motion, AnimatePresence } from 'framer-motion';
import { ReactNode } from 'react';

interface LayerTransitionProps {
  children: ReactNode;
  layerId: number;
  currentLayer: number;
}

export default function LayerTransition({ children, layerId, currentLayer }: LayerTransitionProps) {
  const isActive = currentLayer === layerId;
  const zIndex = isActive ? 10 : layerId < currentLayer ? 5 : 1;
  
  return (
    <AnimatePresence mode="wait">
      {isActive && (
        <motion.div
          key={layerId}
          initial={{ 
            opacity: 0, 
            scale: 0.9,
            rotateX: -15,
            z: -100
          }}
          animate={{ 
            opacity: 1, 
            scale: 1,
            rotateX: 0,
            z: 0
          }}
          exit={{ 
            opacity: 0, 
            scale: 1.1,
            rotateX: 15,
            z: 100
          }}
          transition={{ 
            duration: 0.6, 
            ease: [0.22, 1, 0.36, 1],
            z: { duration: 0.3 }
          }}
          className="absolute inset-0 w-full h-full"
          style={{ 
            zIndex,
            perspective: '1000px',
            transformStyle: 'preserve-3d'
          }}
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
