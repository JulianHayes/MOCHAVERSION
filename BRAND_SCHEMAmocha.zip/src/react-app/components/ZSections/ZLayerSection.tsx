import { motion, AnimatePresence } from 'framer-motion';
import { ReactNode } from 'react';

interface ZLayerSectionProps {
  children: ReactNode;
  layerId: number;
  currentLayer: number;
}

export default function ZLayerSection({ children, layerId, currentLayer }: ZLayerSectionProps) {
  const isActive = currentLayer === layerId;
  
  // Calculate scale and opacity based on Z-axis depth
  const getTransformValues = (id: number, current: number) => {
    if (id === current) return { scale: 1, opacity: 1 };
    const distance = Math.abs(id - current);
    return {
      scale: 1 - (distance * 0.05), // 1 → 0.95 → 0.9
      opacity: 1 - (distance * 0.2)  // 1 → 0.8 → 0.6
    };
  };
  
  const { scale, opacity } = getTransformValues(layerId, currentLayer);
  
  return (
    <div 
      className="absolute inset-0 w-full h-full"
      style={{ 
        perspective: '1500px',
        transformStyle: 'preserve-3d'
      }}
    >
      <AnimatePresence mode="sync">
        <motion.div
          key={layerId}
          initial={{ 
            scale: 0.9,
            opacity: 0
          }}
          animate={{ 
            scale,
            opacity,
            zIndex: isActive ? 10 : layerId < currentLayer ? 5 : 1
          }}
          exit={{ 
            scale: 0.9,
            opacity: 0
          }}
          transition={{ 
            duration: 0.6, 
            ease: [0.65, 0, 0.35, 1], // cubic-bezier(0.65, 0, 0.35, 1)
            scale: { duration: 0.4 },
            opacity: { duration: 0.3 }
          }}
          className={`absolute inset-0 w-full h-full origin-center ${!isActive ? "pointer-events-none" : ""}`}
          style={{ 
            transformOrigin: 'center center',
            transformStyle: 'preserve-3d'
          }}
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
