import { motion, AnimatePresence } from 'framer-motion';
import { Grid3X3, Wrench, Bot } from 'lucide-react';
import { useState } from 'react';

interface ZNavigatorProps {
  currentLayer: number;
  onLayerChange: (layer: number) => void;
}

const layers = [
  { id: 0, label: 'Hero', icon: Grid3X3, desc: 'Brand Foundation' },
  { id: 1, label: 'Schema', icon: Wrench, desc: 'System Architecture' },
  { id: 2, label: 'Agents', icon: Bot, desc: 'Strategic Intelligence' },
];

export default function ZNavigator({ currentLayer, onLayerChange }: ZNavigatorProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);

  const handleLayerChange = (layer: number) => {
    setIsNavigating(true);
    // Brief delay to allow menu to hide before navigation
    setTimeout(() => {
      onLayerChange(layer);
      setIsNavigating(false);
    }, 200);
  };

  return (
    <motion.nav
      initial={{ opacity: 0, x: -40 }}
      animate={{ opacity: 1, x: 0 }}
      className="fixed left-0 top-0 h-screen z-50 flex flex-col"
      style={{ marginTop: '25vh' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex flex-col p-6">
        {/* Logo - Always visible */}
        <motion.button
          onClick={() => handleLayerChange(0)}
          className="text-left group mb-4"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          {/* Frame 5 Logo */}
          <div className="w-16 h-16 mb-2">
            <svg 
              width="100%" 
              height="100%" 
              viewBox="0 0 2668 1945" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
              className="drop-shadow-lg"
            >
              <g filter="url(#filter0_ddddii_171_88)">
                <path d="M1086.01 173C1119.55 173 1146.74 200.485 1146.74 234.39V407.706C1146.74 408.465 1146.72 409.223 1146.7 409.975C1146.71 409.942 1146.72 409.91 1146.74 409.877C1160.27 444.319 1171.25 455.41 1205.32 469.096C1205.28 469.11 1205.25 469.123 1205.21 469.138C1205.96 469.109 1206.71 469.096 1207.47 469.096H1378.92C1379.67 469.096 1380.42 469.109 1381.17 469.138C1381.13 469.124 1381.1 469.11 1381.06 469.096C1415.13 455.41 1426.11 444.319 1439.64 409.877C1439.66 409.912 1439.67 409.947 1439.69 409.981C1439.66 409.226 1439.64 408.467 1439.64 407.706V234.39C1439.64 200.485 1466.84 173 1500.38 173H1964.73C1998.28 173 2025.47 200.485 2025.47 234.39V407.706C2025.47 408.47 2025.46 409.231 2025.43 409.988C2025.44 409.95 2025.46 409.915 2025.47 409.877C2039.01 444.319 2049.98 455.41 2084.05 469.096C2084.01 469.11 2083.99 469.123 2083.95 469.138C2084.69 469.109 2085.45 469.096 2086.2 469.096H2257.66C2291.19 469.096 2318.38 496.581 2318.38 530.486V703.802C2318.38 737.707 2291.19 765.194 2257.66 765.194H2086.2C2052.66 765.194 2025.47 737.707 2025.47 703.802V530.486C2025.47 529.725 2025.48 528.966 2025.51 528.21C2025.49 528.246 2025.48 528.28 2025.47 528.315C2011.93 493.874 2000.95 482.783 1966.89 469.096C1966.92 469.083 1966.96 469.068 1966.98 469.055C1966.24 469.082 1965.49 469.097 1964.73 469.097H1500.38C1499.63 469.097 1498.87 469.082 1498.13 469.055C1498.17 469.068 1498.19 469.083 1498.23 469.096C1464.16 482.783 1453.18 493.874 1439.64 528.315C1439.63 528.282 1439.62 528.247 1439.6 528.212C1439.63 528.967 1439.65 529.725 1439.65 530.486V703.802C1439.65 704.565 1439.63 705.323 1439.6 706.08C1439.62 706.045 1439.63 706.012 1439.64 705.978C1453.18 740.419 1464.16 751.511 1498.23 765.198C1498.19 765.211 1498.15 765.225 1498.13 765.238C1498.87 765.211 1499.63 765.198 1500.38 765.198H1964.73C1998.28 765.198 2025.47 792.682 2025.47 826.587V999.903C2025.47 1000.67 2025.46 1001.43 2025.43 1002.19C2025.44 1002.15 2025.46 1002.11 2025.47 1002.07C2039.01 1036.52 2049.98 1047.61 2084.05 1061.29C2084.01 1061.31 2083.99 1061.32 2083.95 1061.33C2084.69 1061.31 2085.45 1061.29 2086.2 1061.29H2257.66C2291.19 1061.29 2318.38 1088.78 2318.38 1122.68V1296C2318.38 1329.9 2291.19 1357.39 2257.66 1357.39H2086.2C2085.45 1357.39 2084.69 1357.38 2083.95 1357.35C2083.99 1357.36 2084.01 1357.38 2084.05 1357.39C2049.98 1371.08 2039.01 1382.17 2025.47 1416.61C2025.46 1416.57 2025.44 1416.53 2025.43 1416.5C2025.46 1417.25 2025.47 1418.02 2025.47 1418.77V1592.1C2025.47 1626.01 1998.28 1653.49 1964.73 1653.49H1500.38C1466.84 1653.49 1439.64 1626.01 1439.64 1592.1V1418.77C1439.64 1384.87 1466.84 1357.39 1500.38 1357.39H1964.73C1965.49 1357.39 1966.24 1357.4 1966.98 1357.43C1966.96 1357.42 1966.92 1357.4 1966.89 1357.39C2000.95 1343.7 2011.93 1332.61 2025.47 1298.17C2025.48 1298.2 2025.49 1298.24 2025.51 1298.27C2025.48 1297.52 2025.47 1296.76 2025.47 1296V1122.68C2025.47 1121.92 2025.48 1121.16 2025.51 1120.41C2025.49 1120.44 2025.48 1120.48 2025.47 1120.51C2011.93 1086.07 2000.95 1074.98 1966.89 1061.29C1966.92 1061.28 1966.96 1061.26 1966.98 1061.25C1966.24 1061.28 1965.49 1061.29 1964.73 1061.29H1500.38C1499.63 1061.29 1498.87 1061.28 1498.13 1061.25C1498.17 1061.26 1498.19 1061.28 1498.23 1061.29C1464.16 1074.98 1453.18 1086.07 1439.64 1120.51C1439.63 1120.48 1439.62 1120.44 1439.6 1120.41C1439.63 1121.16 1439.65 1121.92 1439.65 1122.68V1296C1439.65 1329.9 1412.46 1357.39 1378.92 1357.39H1207.47C1206.71 1357.39 1205.96 1357.38 1205.22 1357.35C1205.25 1357.36 1205.28 1357.38 1205.32 1357.39C1171.25 1371.08 1160.27 1382.17 1146.74 1416.61C1146.72 1416.57 1146.71 1416.55 1146.7 1416.51C1146.72 1417.26 1146.74 1418.02 1146.74 1418.77V1592.1C1146.74 1626.01 1119.55 1653.49 1086.01 1653.49H621.646C588.105 1653.49 560.915 1626.01 560.915 1592.1V1418.77C560.915 1418.02 560.929 1417.26 560.956 1416.5C560.943 1416.53 560.929 1416.57 560.915 1416.61C547.376 1382.17 536.404 1371.08 502.333 1357.39C502.367 1357.38 502.399 1357.36 502.432 1357.35C501.685 1357.38 500.935 1357.39 500.18 1357.39H328.731C295.19 1357.39 268 1329.9 268 1296V1122.68C268 1088.78 295.19 1061.29 328.731 1061.29H500.18C500.935 1061.29 501.687 1061.31 502.436 1061.33C502.401 1061.32 502.367 1061.31 502.333 1061.29C536.404 1047.61 547.376 1036.52 560.915 1002.07C560.929 1002.11 560.943 1002.14 560.956 1002.18C560.929 1001.42 560.915 1000.66 560.915 999.903V826.587C560.915 825.826 560.929 825.067 560.956 824.311C560.943 824.346 560.929 824.381 560.915 824.416C547.376 789.976 536.404 778.883 502.333 765.198C502.37 765.182 502.408 765.167 502.446 765.151C501.693 765.179 500.939 765.194 500.18 765.194H328.731C295.19 765.194 268 737.707 268 703.802V530.486C268 496.581 295.19 469.096 328.731 469.096H500.18C500.935 469.096 501.687 469.109 502.436 469.138C502.401 469.124 502.367 469.11 502.333 469.096C536.404 455.41 547.376 444.319 560.915 409.877C560.929 409.912 560.943 409.947 560.956 409.981C560.929 409.226 560.915 408.467 560.915 407.706V234.39C560.915 200.485 588.105 173 621.646 173H1086.01ZM1088.25 1061.25C1087.51 1061.28 1086.76 1061.29 1086.01 1061.29H621.646C620.892 1061.29 620.142 1061.28 619.396 1061.25C619.43 1061.26 619.463 1061.28 619.496 1061.29C585.426 1074.98 574.453 1086.07 560.915 1120.51C560.899 1120.47 560.885 1120.43 560.868 1120.4C560.897 1121.16 560.912 1121.92 560.912 1122.68V1296C560.912 1296.76 560.897 1297.53 560.868 1298.28C560.885 1298.25 560.899 1298.21 560.915 1298.17C574.453 1332.61 585.426 1343.7 619.496 1357.39C619.462 1357.4 619.427 1357.42 619.392 1357.43C620.14 1357.4 620.891 1357.39 621.646 1357.39H1086.01C1086.76 1357.39 1087.51 1357.4 1088.26 1357.43C1088.22 1357.42 1088.19 1357.4 1088.15 1357.39C1122.22 1343.7 1133.2 1332.61 1146.74 1298.17C1146.75 1298.2 1146.76 1298.24 1146.78 1298.27C1146.75 1297.52 1146.74 1296.76 1146.74 1296V1122.68C1146.74 1121.92 1146.75 1121.16 1146.78 1120.41C1146.76 1120.44 1146.75 1120.48 1146.74 1120.51C1133.2 1086.07 1122.22 1074.98 1088.15 1061.29C1088.19 1061.28 1088.22 1061.26 1088.25 1061.25ZM1381.18 765.151C1380.43 765.179 1379.67 765.194 1378.92 765.194H1207.47C1206.71 765.194 1205.95 765.179 1205.2 765.151C1205.24 765.167 1205.28 765.182 1205.32 765.198C1171.25 778.883 1160.27 789.976 1146.74 824.416C1146.72 824.384 1146.71 824.35 1146.7 824.317C1146.72 825.071 1146.74 825.827 1146.74 826.587V999.903C1146.74 1000.66 1146.72 1001.42 1146.7 1002.17C1146.71 1002.14 1146.72 1002.11 1146.74 1002.07C1160.27 1036.52 1171.25 1047.61 1205.32 1061.29C1205.28 1061.31 1205.25 1061.32 1205.21 1061.33C1205.96 1061.31 1206.71 1061.29 1207.47 1061.29H1378.92C1379.67 1061.29 1380.42 1061.31 1381.17 1061.33C1381.13 1061.32 1381.1 1061.31 1381.06 1061.29C1415.13 1047.61 1426.11 1036.52 1439.64 1002.07C1439.66 1002.11 1439.67 1002.14 1439.69 1002.18C1439.66 1001.42 1439.64 1000.66 1439.64 999.903V826.587C1439.64 825.826 1439.66 825.067 1439.69 824.311C1439.67 824.346 1439.66 824.381 1439.64 824.416C1426.11 789.976 1415.13 778.883 1381.06 765.198C1381.1 765.182 1381.14 765.167 1381.18 765.151ZM1088.25 469.055C1087.51 469.082 1086.76 469.097 1086.01 469.097H621.646C620.892 469.097 620.142 469.082 619.396 469.055C619.43 469.068 619.463 469.083 619.496 469.096C585.426 482.783 574.453 493.874 560.915 528.315C560.899 528.277 560.885 528.238 560.868 528.2C560.897 528.959 560.912 529.721 560.912 530.486V703.802C560.912 704.568 560.897 705.333 560.868 706.092C560.885 706.055 560.899 706.017 560.915 705.978C574.453 740.419 585.426 751.511 619.496 765.198C619.462 765.211 619.427 765.225 619.392 765.238C620.14 765.211 620.891 765.198 621.646 765.198H1086.01C1086.76 765.198 1087.51 765.211 1088.26 765.238C1088.22 765.225 1088.19 765.211 1088.15 765.198C1122.22 751.511 1133.2 740.419 1146.74 705.978C1146.75 706.013 1146.76 706.048 1146.78 706.083C1146.75 705.326 1146.74 704.566 1146.74 703.802V530.486C1146.74 529.725 1146.75 528.966 1146.78 528.21C1146.76 528.246 1146.75 528.28 1146.74 528.315C1133.2 493.874 1122.22 482.783 1088.15 469.096C1088.19 469.083 1088.22 469.068 1088.25 469.055Z" fill="url(#paint0_linear_171_88)"/>
              </g>
              <path d="M2176.02 1404.7V1392.9H2231.62V1404.7H2210.22V1466H2197.42V1404.7H2176.02ZM2253.8 1466H2241.4V1392.9H2253.8L2277.4 1451.1L2301 1392.9H2313.6V1466H2301.2V1443.5C2301.2 1428.8 2301.2 1424.5 2301.9 1419.3L2283.3 1466H2271.5L2253 1419.4C2253.7 1423.8 2253.8 1430.7 2253.8 1439.8V1466Z" fill="#FF0100"/>
              <defs>
                <filter id="filter0_ddddii_171_88" x="247" y="152" width="2096.38" height="1526.48" filterUnits="userSpaceOnUse" colorInterpolationFilters="sRGB">
                  <feFlood floodOpacity="0" result="BackgroundImageFix"/>
                  <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                  <feOffset dx="7" dy="7"/>
                  <feGaussianBlur stdDeviation="9"/>
                  <feColorMatrix type="matrix" values="0 0 0 0 0.917647 0 0 0 0 0.00392157 0 0 0 0 0 0 0 0 0.9 0"/>
                  <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_171_88"/>
                  <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                  <feOffset dx="-7" dy="-7"/>
                  <feGaussianBlur stdDeviation="7"/>
                  <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 0.00392157 0 0 0 0 0 0 0 0 0.9 0"/>
                  <feBlend mode="normal" in2="effect1_dropShadow_171_88" result="effect2_dropShadow_171_88"/>
                  <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                  <feOffset dx="7" dy="-7"/>
                  <feGaussianBlur stdDeviation="7"/>
                  <feColorMatrix type="matrix" values="0 0 0 0 0.917647 0 0 0 0 0.00392157 0 0 0 0 0 0 0 0 0.2 0"/>
                  <feBlend mode="normal" in2="effect2_dropShadow_171_88" result="effect3_dropShadow_171_88"/>
                  <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                  <feOffset dx="-7" dy="7"/>
                  <feGaussianBlur stdDeviation="7"/>
                  <feColorMatrix type="matrix" values="0 0 0 0 0.917647 0 0 0 0 0.00392157 0 0 0 0 0 0 0 0 0.2 0"/>
                  <feBlend mode="normal" in2="effect3_dropShadow_171_88" result="effect4_dropShadow_171_88"/>
                  <feBlend mode="normal" in="SourceGraphic" in2="effect4_dropShadow_171_88" result="shape"/>
                  <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                  <feOffset dx="-1" dy="-1"/>
                  <feGaussianBlur stdDeviation="1"/>
                  <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
                  <feColorMatrix type="matrix" values="0 0 0 0 0.917647 0 0 0 0 0.00392157 0 0 0 0 0 0 0 0 0.5 0"/>
                  <feBlend mode="normal" in2="shape" result="effect5_innerShadow_171_88"/>
                  <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                  <feOffset dx="1" dy="1"/>
                  <feGaussianBlur stdDeviation="1"/>
                  <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
                  <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 0.00392157 0 0 0 0 0 0 0 0 0.3 0"/>
                  <feBlend mode="normal" in2="effect5_innerShadow_171_88" result="effect6_innerShadow_171_88"/>
                </filter>
                <linearGradient id="paint0_linear_171_88" x1="268" y1="173" x2="1673.31" y2="2119.26" gradientUnits="userSpaceOnUse">
                  <stop offset="1" stopColor="#F20100"/>
                  <stop stopColor="#FF0100"/>
                </linearGradient>
              </defs>
            </svg>
          </div>
          
          {/* Logotype - Shows on hover */}
          <AnimatePresence>
            {isHovered && !isNavigating && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3, ease: [0.65, 0, 0.35, 1] }}
                className="font-display text-xl font-bold text-red-500 tracking-wider"
              >
                BRAND:SCHEMA
                <div className="font-body text-xs text-gray-500 mt-1">
                  Semantic OS
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>

        {/* Navigation items - Show on hover */}
        <AnimatePresence>
          {isHovered && !isNavigating && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ 
                duration: 0.3, 
                ease: [0.65, 0, 0.35, 1],
                staggerChildren: 0.1
              }}
              className="space-y-2 mt-6"
            >
              {layers.map((layer) => {
                const Icon = layer.icon;
                const isActive = currentLayer === layer.id;
                
                return (
                  <motion.button
                    key={layer.id}
                    onClick={() => handleLayerChange(layer.id)}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                    className={`w-full text-left px-4 py-3 transition-all duration-300 group flex items-center space-x-3 ${
                      isActive
                        ? "text-red-500 border-l-2 border-red-500"
                        : "text-gray-400 hover:text-white"
                    }`}
                    whileHover={{ x: isActive ? 0 : 8 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="relative">
                      <Icon className={`w-5 h-5 transition-colors ${
                        isActive ? "text-red-500" : "text-gray-400 group-hover:text-white"
                      }`} />
                      {isActive && (
                        <motion.div
                          className="absolute -left-2 top-1/2 w-2 h-2 bg-red-500 rounded-full"
                          animate={{ scale: [1, 1.2, 1], opacity: [1, 0.7, 1] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                          style={{ transform: 'translateY(-50%)' }}
                        />
                      )}
                    </div>
                    <div>
                      <div className={`font-display font-semibold tracking-wide text-sm ${
                        isActive ? "text-red-500" : "group-hover:text-white"
                      }`}>
                        {layer.label}
                      </div>
                      <div className="font-body text-xs opacity-70">
                        {layer.desc}
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.nav>
  );
}
