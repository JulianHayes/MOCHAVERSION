import { motion } from 'framer-motion';
import { cn } from '@/react-app/lib/utils';
import { Home, Wrench, Bot } from 'lucide-react';

interface NewNavigationProps {
  currentLayer: number;
  onLayerChange: (layer: number) => void;
}

const layers = [
  { id: 0, label: 'Schema', icon: Home, desc: 'Brand Foundation' },
  { id: 1, label: 'Tools', icon: Wrench, desc: 'Immediate Action' },
  { id: 2, label: 'Agents', icon: Bot, desc: 'Strategic Depth' },
];

export default function NewNavigation({ currentLayer, onLayerChange }: NewNavigationProps) {
  return (
    <motion.nav
      initial={{ opacity: 0, x: -40 }}
      animate={{ opacity: 1, x: 0 }}
      className="fixed left-6 top-0 h-screen w-48 z-50 flex flex-col justify-center"
    >
      <div className="bg-semantic-surface/80 backdrop-blur-md border border-semantic-border rounded-lg p-6 min-h-[600px] flex flex-col">
        {/* Logo */}
        <motion.button
          onClick={() => onLayerChange(0)}
          className="mb-12 text-left group"
          style={{ marginTop: '25vh' }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <div className="font-display text-xl font-bold text-brand-accent tracking-wider group-hover:animate-pulse">
            BRAND:SCHEMA
          </div>
          <div className="font-body text-xs text-semantic-muted mt-1">
            Return to Origin
          </div>
        </motion.button>

        {/* Navigation items */}
        <div className="flex-1 space-y-3">
          {layers.map((layer) => {
            const Icon = layer.icon;
            const isActive = currentLayer === layer.id;
            
            return (
              <motion.button
                key={layer.id}
                onClick={() => onLayerChange(layer.id)}
                className={cn(
                  "w-full text-left px-4 py-3 rounded transition-all duration-300 group flex items-center space-x-3",
                  isActive
                    ? "bg-brand-accent/10 text-brand-accent border-l-2 border-brand-accent shadow-[0_0_15px_rgba(255,1,0,0.3)]"
                    : "text-semantic-muted hover:text-semantic-text hover:bg-semantic-surface/50"
                )}
                whileHover={{ x: isActive ? 0 : 8 }}
                whileTap={{ scale: 0.98 }}
              >
                <Icon className={cn(
                  "w-5 h-5 transition-colors",
                  isActive ? "text-brand-accent" : "text-semantic-muted group-hover:text-semantic-text"
                )} />
                <div>
                  <div className={cn(
                    "font-display font-semibold tracking-wide text-sm",
                    isActive ? "text-brand-accent" : "group-hover:text-semantic-text"
                  )}>
                    {layer.label}
                  </div>
                  <div className="font-body text-xs opacity-70">
                    {layer.desc}
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>
        
        {/* Layer indicator */}
        <div className="mt-6 pt-4 border-t border-semantic-border">
          <div className="font-display text-xs text-semantic-muted tracking-wider">
            Z = {currentLayer} / DEPTH = {currentLayer === 0 ? 'SURFACE' : currentLayer === 1 ? 'ACTION' : 'STRATEGY'}
          </div>
        </div>
      </div>
    </motion.nav>
  );
}
