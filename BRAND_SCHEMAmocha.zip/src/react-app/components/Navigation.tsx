import { motion } from 'framer-motion';
import { cn } from '@/react-app/lib/utils';

interface NavigationProps {
  currentLayer: number;
  onLayerChange: (layer: number) => void;
}

const layers = [
  { id: 0, label: 'SURFACE', desc: 'Entry point' },
  { id: 1, label: 'TOOLS', desc: 'Action layer' },
  { id: 2, label: 'AGENTS', desc: 'Strategic depth' },
  { id: 3, label: 'SCHEMA', desc: 'Core system' },
];

export default function Navigation({ currentLayer, onLayerChange }: NavigationProps) {
  return (
    <motion.nav
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed top-6 left-6 z-50 font-display text-sm"
    >
      <div className="bg-semantic-surface/80 backdrop-blur-md border border-semantic-border rounded-lg p-4">
        <div className="text-brand-accent font-bold text-xs mb-3 tracking-wider">
          BRAND:SCHEMA
        </div>
        <div className="space-y-2">
          {layers.map((layer) => (
            <motion.button
              key={layer.id}
              onClick={() => onLayerChange(layer.id)}
              className={cn(
                "block w-full text-left px-3 py-2 rounded transition-all",
                currentLayer === layer.id
                  ? "bg-brand-accent text-brand-dark font-bold"
                  : "text-semantic-muted hover:text-semantic-text hover:bg-semantic-surface"
              )}
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="font-semibold">{layer.label}</div>
              <div className="text-xs opacity-70">{layer.desc}</div>
            </motion.button>
          ))}
        </div>
        
        <div className="mt-4 pt-3 border-t border-semantic-border">
          <div className="text-xs text-semantic-muted">
            LAYER {currentLayer.toString().padStart(2, '0')}
          </div>
        </div>
      </div>
    </motion.nav>
  );
}
