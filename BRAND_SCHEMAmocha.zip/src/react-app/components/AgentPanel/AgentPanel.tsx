import { motion } from 'framer-motion';
import AgentCard from './AgentCard';

const agents = [
  {
    id: 'brand-strategy',
    name: 'BRAND:STRATEGY Agent',
    functionLabel: 'Strategic Foundation',
    description: [
      'Builds clarity around brand purpose',
      'Signals authority in target domains',
      'Creates semantic consistency'
    ],
    status: 'active'
  },
  {
    id: 'brand-management',
    name: 'BRAND:MANAGEMENT Agent',
    functionLabel: 'System Architecture',
    description: [
      'Applies structural frameworks',
      'Maintains brand consistency',
      'Orchestrates component systems'
    ],
    status: 'active'
  },
  {
    id: 'brand-marketing',
    name: 'BRAND:MARKETING Agent',
    functionLabel: 'Content Intelligence',
    description: [
      'Writes for algorithmic discovery',
      'Resonates with human audiences',
      'Optimizes for machine parsing'
    ],
    status: 'active'
  },
  {
    id: 'brand-intelligence',
    name: 'BRAND:INTELLIGENCE Agent',
    functionLabel: 'Analytics Engine',
    description: [
      'Tracks brand mention patterns',
      'Measures semantic impact',
      'Identifies optimization vectors'
    ],
    status: 'active'
  }
];

export default function AgentPanel() {
  return (
    <div className="w-full h-screen bg-black overflow-y-auto">
      <div className="container mx-auto px-6 py-12 ml-[15vw]">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <h1 className="font-display text-5xl font-bold mb-4 text-white tracking-wide">
            AGENT PANEL
          </h1>
          <p className="font-body text-xl text-gray-400 max-w-2xl">
            Autonomous intelligence systems for strategic brand operations.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.15
              }
            }
          }}
        >
          {agents.map((agent) => (
            <motion.div
              key={agent.id}
              variants={{
                hidden: { opacity: 0, y: 30 },
                visible: { opacity: 1, y: 0 }
              }}
            >
              <AgentCard {...agent} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
