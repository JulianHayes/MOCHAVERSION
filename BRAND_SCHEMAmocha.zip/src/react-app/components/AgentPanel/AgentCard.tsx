import { motion } from 'framer-motion';

interface AgentCardProps {
  id: string;
  name: string;
  functionLabel: string;
  description: string[];
  status: string;
}

export default function AgentCard({ id, name, functionLabel, description, status }: AgentCardProps) {
  return (
    <motion.div
      className="h-full bg-transparent border border-gray-700 p-6 group"
      whileHover={{ 
        scale: 1.02,
        transition: { duration: 0.2, ease: [0.65, 0, 0.35, 1] }
      }}
      whileTap={{ scale: 0.98 }}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="font-display text-xl font-bold text-white mb-1 tracking-wide">
            {name}
          </h3>
          <div className="font-body text-sm text-gray-400">
            {functionLabel}
          </div>
        </div>
        
        {/* Status light */}
        <div className="flex items-center space-x-2">
          <motion.div
            className="w-3 h-3 bg-green-500 rounded-full"
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [1, 0.7, 1] 
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: [0.65, 0, 0.35, 1]
            }}
          />
          <span className="text-xs font-display text-green-500 tracking-wider">
            {status.toUpperCase()}
          </span>
        </div>
      </div>

      {/* Description bullets */}
      <div className="mb-8">
        <ul className="space-y-2">
          {description.map((item, index) => (
            <li key={index} className="font-body text-sm text-gray-400 flex items-start">
              <span className="text-red-500 mr-3 mt-1">•</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Engage button */}
      <motion.button
        className="w-full py-3 bg-transparent border border-gray-700 text-white font-display text-sm tracking-wide hover:border-red-500 hover:text-red-500 transition-colors duration-300"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        [ ENGAGE AGENT ]
      </motion.button>
      
      {/* Agent ID */}
      <div className="mt-4 text-xs font-display text-gray-600 tracking-wider text-center">
        {id.toUpperCase()}
      </div>
    </motion.div>
  );
}
