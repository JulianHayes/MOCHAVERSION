import { useState, useEffect } from 'react';
import ZLayerSection from '@/react-app/components/ZSections/ZLayerSection';
import ZNavigator from '@/react-app/components/ZSections/ZNavigator';
import HeroLayer from '@/react-app/components/layers/HeroLayer';
import SchemaGrid from '@/react-app/components/SchemaGrid/SchemaGrid';
import AgentPanel from '@/react-app/components/AgentPanel/AgentPanel';

export default function RebuiltHome() {
  const [currentLayer, setCurrentLayer] = useState(0);

  const handleNavigate = (layer: number) => {
    setCurrentLayer(layer);
  };

  // Keyboard shortcuts for Z-axis navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey) {
        if (e.key === 'ArrowRight' && currentLayer < 2) {
          e.preventDefault();
          setCurrentLayer(prev => prev + 1);
        } else if (e.key === 'ArrowLeft' && currentLayer > 0) {
          e.preventDefault();
          setCurrentLayer(prev => prev - 1);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentLayer]);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black">
      {/* Sidebar Navigation */}
      <ZNavigator 
        currentLayer={currentLayer} 
        onLayerChange={handleNavigate} 
      />

      {/* Layer container with perspective */}
      <div 
        className="relative w-full h-full"
        style={{ 
          perspective: '1500px',
          transformStyle: 'preserve-3d'
        }}
      >
        {/* Hero Layer (Z = 0) */}
        <ZLayerSection layerId={0} currentLayer={currentLayer}>
          <HeroLayer onNavigate={handleNavigate} />
        </ZLayerSection>

        {/* Schema Grid (Z = 1) */}
        <ZLayerSection layerId={1} currentLayer={currentLayer}>
          <SchemaGrid />
        </ZLayerSection>

        {/* Agent Panel (Z = 2) */}
        <ZLayerSection layerId={2} currentLayer={currentLayer}>
          <AgentPanel />
        </ZLayerSection>
      </div>

      {/* Coordinate overlay */}
      <div className="fixed bottom-4 right-4 font-display text-xs text-gray-600 tracking-wider pointer-events-none">
        Z:{currentLayer.toString().padStart(2, '0')} | X:00 | Y:00
      </div>
    </div>
  );
}
