import { useState, useEffect } from 'react';
import NewNavigation from '@/react-app/components/NewNavigation';
import NewLayerTransition from '@/react-app/components/NewLayerTransition';
import HeroLayer from '@/react-app/components/layers/HeroLayer';
import NewToolsLayer from '@/react-app/components/layers/NewToolsLayer';
import NewAgentsLayer from '@/react-app/components/layers/NewAgentsLayer';

export default function NewHome() {
  const [currentLayer, setCurrentLayer] = useState(0);

  const handleNavigate = (layer: number) => {
    setCurrentLayer(layer);
  };

  // Keyboard shortcuts for Z-axis navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey) {
        if (e.key === 'ArrowRight' && currentLayer < 2) {
          e.preventDefault();
          setCurrentLayer(prev => prev + 1);
        } else if (e.key === 'ArrowLeft' && currentLayer > 0) {
          e.preventDefault();
          setCurrentLayer(prev => prev - 1);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentLayer]);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-semantic-bg">
      {/* Sidebar Navigation */}
      <NewNavigation 
        currentLayer={currentLayer} 
        onLayerChange={handleNavigate} 
      />

      {/* Layer container with perspective */}
      <div 
        className="relative w-full h-full ml-48"
        style={{ 
          perspective: '1500px',
          transformStyle: 'preserve-3d'
        }}
      >
        {/* Hero Layer (Z = 0) */}
        <NewLayerTransition layerId={0} currentLayer={currentLayer}>
          <HeroLayer onNavigate={handleNavigate} />
        </NewLayerTransition>

        {/* Tools Layer (Z = 1) */}
        <NewLayerTransition layerId={1} currentLayer={currentLayer}>
          <NewToolsLayer />
        </NewLayerTransition>

        {/* Agents Layer (Z = 2) */}
        <NewLayerTransition layerId={2} currentLayer={currentLayer}>
          <NewAgentsLayer />
        </NewLayerTransition>
      </div>

      {/* Subtle coordinate overlay */}
      <div className="fixed bottom-4 right-4 font-display text-xs text-semantic-muted/50 tracking-wider pointer-events-none">
        Z:{currentLayer.toString().padStart(2, '0')} | X:00 | Y:00
      </div>

      {/* Ambient background effects */}
      <div className="fixed inset-0 pointer-events-none -z-10">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-brand-accent/3 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-brand-accent/2 rounded-full blur-3xl animate-float" style={{ animationDelay: '3s' }} />
      </div>
    </div>
  );
}
