import { useState } from 'react';
import Navigation from '@/react-app/components/Navigation';
import LayerTransition from '@/react-app/components/LayerTransition';
import SurfaceLayer from '@/react-app/components/layers/SurfaceLayer';
import ToolsLayer from '@/react-app/components/layers/ToolsLayer';
import AgentsLayer from '@/react-app/components/layers/AgentsLayer';
import SchemaLayer from '@/react-app/components/layers/SchemaLayer';

export default function Home() {
  const [currentLayer, setCurrentLayer] = useState(0);

  const handleEnterSystem = () => {
    setCurrentLayer(1); // Move to Tools layer
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-semantic-bg">
      {/* Navigation */}
      <Navigation 
        currentLayer={currentLayer} 
        onLayerChange={setCurrentLayer} 
      />

      {/* Layer container with perspective */}
      <div 
        className="relative w-full h-full"
        style={{ 
          perspective: '1000px',
          transformStyle: 'preserve-3d'
        }}
      >
        {/* Surface Layer */}
        <LayerTransition layerId={0} currentLayer={currentLayer}>
          <SurfaceLayer onEnter={handleEnterSystem} />
        </LayerTransition>

        {/* Tools Layer */}
        <LayerTransition layerId={1} currentLayer={currentLayer}>
          <ToolsLayer />
        </LayerTransition>

        {/* Agents Layer */}
        <LayerTransition layerId={2} currentLayer={currentLayer}>
          <AgentsLayer />
        </LayerTransition>

        {/* Schema Layer */}
        <LayerTransition layerId={3} currentLayer={currentLayer}>
          <SchemaLayer />
        </LayerTransition>
      </div>

      {/* Ambient background effects */}
      <div className="fixed inset-0 pointer-events-none -z-10">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-brand-accent/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-brand-tertiary/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/2 w-48 h-48 bg-brand-secondary/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '4s' }} />
      </div>
    </div>
  );
}
